package com.seisma.employeepay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeepayApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeepayApplication.class, args);
	}

}
